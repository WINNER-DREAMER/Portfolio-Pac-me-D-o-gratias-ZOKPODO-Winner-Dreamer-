# Portfolio — Pacôme Déo-gratias ZOKPODO (Winner Dreamer)

Portfolio professionnel multilingue de **Pacôme Déo-gratias ZOKPODO**, alias *Winner Dreamer* — Digital Marketer, Web Developer & English Trainer.

🔗 **Site en ligne :** [à compléter une fois déployé]

---

## 👋 À propos

Consultant digital marketing et développeur web basé à Kumasi (Ghana), originaire du Bénin. J'accompagne depuis 3 ans des entrepreneurs et petites entreprises à travers l'Afrique de l'Ouest dans leur transformation numérique, tout en formant des professionnels à l'anglais pratique via [Winner English Club](https://winner-dreamer.github.io/WINNER-ENGLISH-CLUB2/).

## 🛠️ Stack technique

Ce site est construit en **HTML / CSS / JavaScript pur**, sans framework ni CMS, hébergé gratuitement sur **GitHub Pages**.

- Structure multilingue (FR / EN / ES / DE / IT) via fichiers JSON + sélecteur de langue JS
- Formulaire de contact géré par [Formspree](https://formspree.io)
- Design responsive, palette navy & gold

## 📂 Structure du projet

```
portfolio/
├── index.html
├── style.css
├── script.js
├── /lang
│   ├── fr.json
│   ├── en.json
│   ├── es.json
│   ├── de.json
│   └── it.json
├── /assets
│   ├── /images
│   └── CV-Winner-Dreamer-2026.pdf
└── README.md
```

## ✨ Sections du site

- **Accueil** — présentation et accroche
- **À propos** — parcours et bio
- **Services** — création de sites web, marketing digital, SEO, rédaction, formation en anglais, gestion de projet
- **Portfolio** — projets réalisés (Winner English Club, Digit Communication, ANAGKAZO-INTLE...) et projets à venir
- **Expérience** — parcours professionnel
- **Contact** — formulaire, WhatsApp, réseaux sociaux, téléchargement du CV

## 🌍 Langues disponibles

Le site s'adapte selon les besoins du visiteur parmi : Français, Anglais, Espagnol, Allemand, Italien.

## 📬 Me contacter

- 📧 dreamerwinner94@gmail.com
- 💼 [LinkedIn](https://www.linkedin.com/in/pacôme-déo-gratias-zokpodo-a82969425)
- 📘 [Facebook](https://www.facebook.com/pacome.deo.gratias.zokpodo.2025)

---

*Ce portfolio a été conçu et développé par Pacôme Déo-gratias ZOKPODO lui-même, avec l'appui de Claude (Anthropic) pour la génération du code.*
